"""Phase 3B: 3-variant parallel GEMM (N=384) + 10-point tile sweep + roofline mapping."""
import multiprocessing as mp
import random
from array import array
from multiprocessing import shared_memory

from harness import (attach_shm, detect_hw, emit_verify_tag, get_p_phys, get_student_seed,
                     load_result, md_table, pick, run_benchmark, save_result)

N = pick(384, 48)
WARM, TIMED = pick((1, 5), (1, 2))
TILES = [4, 8, 12, 16, 24, 32, 48, 64, 96, 128]
_A = _B = _C = None
_N = 0


def _init(names, n):
    global _A, _B, _C, _N, _keep
    _keep = [attach_shm(x) for x in names]
    _A, _B, _C = (s.buf.cast("d") for s in _keep)
    _N = n


def v1(r0, r1, _bs):
    A, B, C, n = _A, _B, _C, _N
    for i in range(r0, r1):
        ib = i * n
        for j in range(n):
            dot = 0.0
            for k in range(n):
                dot += A[ib + k] * B[k * n + j]
            C[ib + j] = dot


def v2(r0, r1, _bs):
    A, B, C, n = _A, _B, _C, _N
    for i in range(r0, r1):
        ib = i * n
        crow = [0.0] * n
        for k in range(n):
            a_ik = A[ib + k]
            brow = B[k * n:(k + 1) * n]
            crow = [c + a_ik * b for c, b in zip(crow, brow)]
        C[ib:ib + n] = array("d", crow)


def v3(r0, r1, bs):
    A, B, C, n = _A, _B, _C, _N
    C[r0 * n:r1 * n] = array("d", bytes(8 * (r1 - r0) * n))      # zero my rows
    for ii in range(r0, r1, bs):
        imax = min(ii + bs, r1)
        for kk in range(0, n, bs):
            kmax = min(kk + bs, n)
            for jj in range(0, n, bs):
                jmax = min(jj + bs, n)
                for i in range(ii, imax):                       # micro-kernel: i, k, j
                    ib = i * n
                    cseg = C[ib + jj:ib + jmax].tolist()
                    for k in range(kk, kmax):
                        a_ik = A[ib + k]                        # hoisted out of the j-loop
                        brow = B[k * n + jj:k * n + jmax]
                        cseg = [c + a_ik * b for c, b in zip(cseg, brow)]
                    C[ib + jj:ib + jmax] = array("d", cseg)


def task(args):
    which, r0, r1, bs = args
    {1: v1, 2: v2, 3: v3}[which](r0, r1, bs)


def main():
    seed = get_student_seed()
    p = get_p_phys()
    hw = detect_hw()
    l1 = (hw["l1d_kb"] or 32) * 1024
    l2 = (hw["l2_kb"] or 256) * 1024
    random.seed(12345)
    shms = [shared_memory.SharedMemory(create=True, size=N * N * 8) for _ in range(3)]
    views = [s.buf.cast("d") for s in shms]
    pA, pB, pC = views
    for i in range(N * N):
        pA[i] = random.random()
        pB[i] = random.random()
    rows = [(N * t // p, N * (t + 1) // p) for t in range(p)]
    flops = 2 * N ** 3
    gf = lambda ms: flops / (ms * 1e6)
    res = {}
    try:
        with mp.Pool(p, initializer=_init, initargs=([s.name for s in shms], N)) as pool:
            def go(which, bs=0):
                return run_benchmark(
                    lambda: pool.map(task, [(which, a, b, bs) for a, b in rows], chunksize=1),
                    WARM, TIMED)
            s1 = go(1); c1 = pC[:N * N].tolist()
            s2 = go(2); c2 = pC[:N * N].tolist()
            print(f"V1 {s1.median_ms:.0f} ms ({gf(s1.median_ms):.4f} GFLOP/s) | "
                  f"V2 {s2.median_ms:.0f} ms ({gf(s2.median_ms):.4f} GFLOP/s) | "
                  f"max|C1-C2|={max(abs(x-y) for x, y in zip(c1, c2)):.2e}")
            for bs in TILES:
                st = go(3, bs)
                diff = max(abs(x - y) for x, y in zip(pC[:N * N].tolist(), c2))
                res[bs] = (st, diff)
                print(f"  BS={bs:>3}: {st.median_ms:8.0f} ms  {gf(st.median_ms):.4f} GFLOP/s  "
                      f"max|C3-C2|={diff:.1e}")
    finally:
        for v in views:
            v.release()
        for s in shms:
            s.close(); s.unlink()

    bs_star = max(res, key=lambda b: gf(res[b][0].median_ms))
    g1, g2, g3 = gf(s1.median_ms), gf(s2.median_ms), gf(res[bs_star][0].median_ms)
    wt = lambda b: 3 * b * b * 8
    fits = lambda w: "L1d" if w <= l1 else ("L2" if w <= l2 else "> L2")
    trows = [[b, wt(b), f"{wt(b)/1024:.1f}", fits(wt(b)), f"{res[b][0].median_ms:.1f}",
              f"{res[b][0].iqr_ms:.1f}", f"{gf(res[b][0].median_ms):.4f}",
              f"{res[b][1]:.1e}", "<- BS*" if b == bs_star else ""] for b in TILES]
    t_tile = md_table(["BS", "W_tile (B)", "W_tile (KB)", "Fits in", "Median (ms)", "IQR (ms)",
                       "GFLOP/s", "max|C3-C2|", ""], trows)
    t_var = md_table(["Variant", "Median (ms)", "IQR (ms)", "GFLOP/s"], [
        ["1 naive i-j-k", f"{s1.median_ms:.1f}", f"{s1.iqr_ms:.1f}", f"{g1:.4f}"],
        ["2 i-k-j", f"{s2.median_ms:.1f}", f"{s2.iqr_ms:.1f}", f"{g2:.4f}"],
        [f"3 tiled (BS*={bs_star})", f"{res[bs_star][0].median_ms:.1f}",
         f"{res[bs_star][0].iqr_ms:.1f}", f"{g3:.4f}"]])

    roof = load_result("task3a")
    if roof:
        BW, PK = roof["bw_gbs"], roof["p_gflops"]
        att = lambda I: min(PK, I * BW)
        pts = [("Variant 1", 0.125, g1), ("Variant 2 (assumes C row in L1: 2 FLOP / 8 B)", 0.25, g2),
               (f"Variant 3 (BS*={bs_star})", bs_star / 12, g3)]
        t_roof = md_table(["Kernel", "I (FLOP/B)", "Attainable (GFLOP/s)", "Achieved (GFLOP/s)",
                           "% of attainable"],
                          [[n, f"{I:.3f}", f"{att(I):.4f}", f"{g:.4f}", f"{g/att(I)*100:.1f}%"]
                           for n, I, g in pts])
    else:
        t_roof = "_Run task3a_roofline.py first to get the roofline mapping._"

    tag = emit_verify_tag("PHASE3", seed, g1, g3)
    print("\n" + t_var + "\n\n" + t_tile + "\n\n" + t_roof + "\n" + tag)
    analysis = (
        f"Empirical optimum BS* = {bs_star}: W_tile = {wt(bs_star)/1024:.1f} KB, which fits in "
        f"{fits(wt(bs_star))} (L1d = {l1//1024} KB, L2 = {l2//1024} KB"
        + ("" if hw['l1d_kb'] else "; **L1d/L2 assumed - set from your Phase 0 table**") + "). "
        "Small tiles (4-12) lose to per-tile loop/slice overhead; the classic cache-capacity penalty "
        "appears only once 3*BS^2*8 B exceeds L1d/L2. In pure Python, interpreter overhead per slice "
        "and per list-comprehension is large relative to cache-miss cost, so BS* often lands higher "
        "than the textbook L1-fit value (and may sit at the largest tiles); state which regime you "
        "observe. Variants 1->2 gain comes from unit-stride B access and hoisting a_ik/index math "
        "into a C-level comprehension; Variant 3 adds register/cache reuse of the C segment.\n\n"
        "Roofline I_tiled(BS*) = BS*/12 FLOP/B (3 matrices of BS x BS doubles resident: 2 BS^3 FLOP over "
        "3 BS^2 x 8 B).")
    save_result("task3b", dict(verify=tag, md=t_var + "\n\n" + t_tile + "\n\n" + t_roof,
                               analysis=analysis))


if __name__ == "__main__":
    main()
