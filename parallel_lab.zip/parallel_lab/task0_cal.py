"""Phase 0 checkpoint: timer calibration + VERIFY_HASH[PHASE0]."""
import multiprocessing as mp
import time

from harness import (emit_verify_tag, get_student_seed, pick, save_result, detect_hw,
                     md_table)


def main():
    seed = get_student_seed()
    pc = time.perf_counter_ns
    n = pick(2_000_000, 200_000)

    pc()  # warm-up
    t0 = pc()
    for _ in range(n):
        pc()
    t1 = pc()
    avg_ns = (t1 - t0) / n

    t0 = pc()
    for _ in range(n):
        pass
    loop_ns = (pc() - t0) / n               # empty-loop overhead, for reference

    deltas = []
    for _ in range(100_000):
        a = pc()
        b = pc()
        deltas.append(b - a)
    floor_ns = min(d for d in deltas if d > 0) if any(d > 0 for d in deltas) else 0

    hw = mp.cpu_count()
    print(f"mp.cpu_count()                    : {hw}")
    print(f"avg perf_counter_ns call latency  : {avg_ns:.2f} ns  ({n:,} reads)")
    print(f"  of which empty-loop overhead    : {loop_ns:.2f} ns")
    print(f"timer noise floor (min back-to-back delta): {floor_ns} ns")
    tag = emit_verify_tag("PHASE0", seed, avg_ns, float(hw))
    print(tag)

    h = detect_hw()
    save_result("task0", dict(
        verify=tag, hw=h,
        md=md_table(["Metric", "Value"], [
            ["mp.cpu_count() (P_log)", hw],
            ["Avg perf_counter_ns latency (ns)", f"{avg_ns:.2f}"],
            ["Empty-loop overhead (ns)", f"{loop_ns:.2f}"],
            ["Noise floor (ns)", floor_ns]]),
        analysis=(f"Each timer read costs ~{avg_ns:.0f} ns, so any benchmark region shorter than "
                  f"~{avg_ns*1000/1e6:.2f} ms would have >0.1% timer overhead; all later "
                  f"experiments run for seconds, so timer error is negligible.")))


if __name__ == "__main__":
    main()
