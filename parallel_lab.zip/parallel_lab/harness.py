"""harness.py -- Zero-dependency Python 3 telemetry & verification framework.

Provides: ns-resolution timing (perf_counter_ns), warm-up, median/IQR stats,
the FNV-1a verification-hash generator, hardware detection and small helpers
shared by every task script.

Env vars:
  LAB_STUDENT_ID  your student ID (digits are used as student_seed)
  P_PHYS          override detected physical-core count
  LAB_SMOKE=1     tiny problem sizes, for checking the scripts run at all
"""
import json
import multiprocessing as mp
import os
import platform
import re
import subprocess
import time
from dataclasses import dataclass
from multiprocessing import shared_memory
from pathlib import Path
from typing import Callable

SMOKE = os.environ.get("LAB_SMOKE") == "1"
RESULTS_DIR = Path(__file__).resolve().parent / "results"


def pick(full, small):
    """Return the full-size parameter, or the tiny one in smoke-test mode."""
    return small if SMOKE else full


@dataclass
class BenchStats:
    min_ms: float
    median_ms: float
    iqr_ms: float
    max_ms: float


def fnv1a_hash(s: str) -> int:
    h = 14695981039346656037
    for b in s.encode("utf-8"):
        h ^= b
        h = (h * 1099511628211) & 0xFFFFFFFFFFFFFFFF
    return h


def summarize(samples) -> BenchStats:
    samples = sorted(samples)
    n = len(samples)
    mid = n // 2
    med = samples[mid] if n % 2 == 1 else 0.5 * (samples[mid - 1] + samples[mid])
    q25 = samples[n // 4]
    q75 = samples[(3 * n) // 4]
    return BenchStats(samples[0], med, q75 - q25, samples[-1])


def run_benchmark(fn: Callable[[], None], warmup_runs: int = 3, timed_runs: int = 9) -> BenchStats:
    for _ in range(warmup_runs):
        fn()
    samples = []
    for _ in range(timed_runs):
        t0 = time.perf_counter_ns()
        fn()
        t1 = time.perf_counter_ns()
        samples.append((t1 - t0) / 1e6)
    return summarize(samples)


def run_benchmark_ret(fn, warmup_runs: int = 3, timed_runs: int = 9):
    """Like run_benchmark, but fn times itself and returns (ms, extra).
    Returns (BenchStats over ms, list of (ms, extra) rows)."""
    for _ in range(warmup_runs):
        fn()
    rows = [fn() for _ in range(timed_runs)]
    return summarize([r[0] for r in rows]), rows


def emit_verify_tag(task_id: str, student_seed: int,
                    primary_metric: float, secondary_metric: float) -> str:
    hw = mp.cpu_count()
    payload = (f"{task_id}|{student_seed}|{hw}|"
               f"{primary_metric:.4f}|{secondary_metric:.4f}")
    sig = fnv1a_hash(payload)
    return f"VERIFY_HASH[{task_id}]: {sig:016X} (P_log={hw})"


def get_student_seed() -> int:
    digits = re.sub(r"\D", "", os.environ.get("LAB_STUDENT_ID", ""))
    if not digits:
        raise SystemExit("Set your ID first, e.g.  export LAB_STUDENT_ID=21K3456  "
                         "(PowerShell: $env:LAB_STUDENT_ID='21K3456')")
    return int(digits)


# ---------------------------------------------------------------- hardware
def _run(cmd):
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=30).stdout
    except Exception:
        return ""


def _to_kb(text, per_instance=True):
    m = re.search(r"([\d.]+)\s*(KiB|MiB|GiB|KB|MB|K|M)\b", text)
    if not m:
        return None
    v = float(m.group(1))
    unit = m.group(2).upper()
    if unit.startswith("M"):
        v *= 1024
    elif unit.startswith("G"):
        v *= 1024 * 1024
    inst = re.search(r"\((\d+)\s+instance", text)
    if per_instance and inst:
        v /= int(inst.group(1))
    return v


_HW = None


def detect_hw() -> dict:
    """Best-effort hardware audit. Unknown fields are None (fill by hand)."""
    global _HW
    if _HW is not None:
        return _HW
    hw = dict(cpu_model=None, p_phys=None, p_log=mp.cpu_count(), line_bytes=None,
              l1d_kb=None, l2_kb=None, l3_kb=None,
              py_os=f"Python {platform.python_version()} / {platform.system()} {platform.release()}")
    sysname = platform.system()
    try:
        if sysname == "Linux":
            d = {}
            for line in _run(["lscpu"]).splitlines():
                if ":" in line:
                    k, v = line.split(":", 1)
                    d[k.strip()] = v.strip()
            hw["cpu_model"] = d.get("Model name")
            if "Core(s) per socket" in d:
                hw["p_phys"] = int(d["Core(s) per socket"]) * int(d.get("Socket(s)", "1"))
            for key, name, per in (("L1d cache", "l1d_kb", True), ("L2 cache", "l2_kb", True),
                                   ("L3 cache", "l3_kb", False)):
                if key in d:
                    hw[name] = _to_kb(d[key], per)
            out = _run(["getconf", "LEVEL1_DCACHE_LINESIZE"]).strip()
            hw["line_bytes"] = int(out) if out.isdigit() else None
        elif sysname == "Darwin":
            def sc(k):
                return _run(["sysctl", "-n", k]).strip()
            hw["cpu_model"] = sc("machdep.cpu.brand_string") or None
            hw["p_phys"] = int(sc("hw.physicalcpu") or 0) or None
            hw["line_bytes"] = int(sc("hw.cachelinesize") or 0) or None
            for k, name in (("hw.l1dcachesize", "l1d_kb"), ("hw.l2cachesize", "l2_kb"),
                            ("hw.l3cachesize", "l3_kb")):
                v = sc(k)
                hw[name] = int(v) / 1024 if v.isdigit() else None
        elif sysname == "Windows":
            out = _run(["powershell", "-NoProfile", "-Command",
                        "Get-CimInstance Win32_Processor | Select Name,NumberOfCores,"
                        "L2CacheSize,L3CacheSize | ConvertTo-Json"])
            j = json.loads(out)
            j = j[0] if isinstance(j, list) else j
            hw["cpu_model"] = j.get("Name")
            hw["p_phys"] = j.get("NumberOfCores")
            hw["l2_kb"] = j.get("L2CacheSize")
            hw["l3_kb"] = (j.get("L3CacheSize") or 0)
    except Exception:
        pass
    _HW = hw
    return hw


def get_p_phys() -> int:
    if os.environ.get("P_PHYS"):
        return int(os.environ["P_PHYS"])
    return detect_hw()["p_phys"] or mp.cpu_count()


def p_sweep(p_phys: int, p_log: int):
    s = {1, p_phys, p_log}
    p = 2
    while p <= p_log:
        s.add(p)
        p *= 2
    return sorted(s)


# ------------------------------------------------------------------ helpers
def attach_shm(name: str):
    try:
        return shared_memory.SharedMemory(name=name, track=False)   # Python 3.13+
    except TypeError:
        return shared_memory.SharedMemory(name=name)


def md_table(headers, rows) -> str:
    out = ["| " + " | ".join(headers) + " |", "|" + "|".join("---" for _ in headers) + "|"]
    for r in rows:
        out.append("| " + " | ".join(str(c) for c in r) + " |")
    return "\n".join(out)


def save_result(name: str, data: dict):
    RESULTS_DIR.mkdir(exist_ok=True)
    (RESULTS_DIR / f"{name}.json").write_text(json.dumps(data, indent=2))


def load_result(name: str):
    f = RESULTS_DIR / f"{name}.json"
    return json.loads(f.read_text()) if f.exists() else None


def get_p_log() -> int:
    """Logical thread count (env P_LOG override is for testing only)."""
    return int(os.environ["P_LOG"]) if os.environ.get("P_LOG") else mp.cpu_count()
