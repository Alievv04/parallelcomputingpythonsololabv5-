"""Assemble lab_report_<ID>.md from results/*.json."""
import os
import re

from harness import detect_hw, load_result, md_table, get_p_phys

PHASES = [("task0", "Phase 0: Hardware Audit & Harness Calibration"),
          ("task1", "Phase 1: False Sharing & Karp-Flatt"),
          ("task2", "Phase 2: Strong vs Weak Scaling"),
          ("task3a", "Phase 3A: Empirical Roofline"),
          ("task3b", "Phase 3B: GEMM Optimization & Tile Sweep"),
          ("task4", "Phase 4: Skewed Workloads & Load Imbalance")]


def main():
    sid = os.environ.get("LAB_STUDENT_ID", "YourID")
    f = lambda v, u="": "[FILL BY HAND]" if v in (None, 0) else f"{v:g}{u}"
    h = detect_hw()
    out = [f"# Performance Evaluation and Optimization in Parallel Computing -- Lab Report ({sid})\n",
           "## Hardware baseline\n",
           md_table(["Hardware Parameter", "Measured Value", "Hardware Parameter", "Measured Value"], [
               ["CPU Model String", h["cpu_model"] or "[FILL BY HAND]", "L1 Data Cache (per core)", f(h["l1d_kb"], " KB")],
               ["Physical Cores (P_phys)", get_p_phys(), "L2 Cache Size", f(h["l2_kb"], " KB")],
               ["Logical Threads (P_log)", h["p_log"], "L3 Cache Size (Shared)", f(h["l3_kb"] and h["l3_kb"] / 1024, " MB")],
               ["Cache Line Size (L_bytes)", f(h["line_bytes"], " B"), "Python Version & OS", h["py_os"]]]),
           "\n_Cross-check every value against the OS command output in section 1.1 of the handout._\n"]
    for key, title in PHASES:
        r = load_result(key)
        out.append(f"## {title}\n")
        if not r:
            out.append(f"_No results yet: run the script for {key}._\n")
            continue
        out.append(r["md"] + "\n")
        if r.get("analysis"):
            out.append("**Analysis**\n\n" + r["analysis"] + "\n")
        if r.get("verify"):
            out.append("```\n" + r["verify"] + "\n```\n")
    path = f"lab_report_{re.sub(r'[^A-Za-z0-9_-]', '', sid)}.md"
    open(path, "w", encoding="utf-8").write("\n".join(out))
    print("wrote", path)


if __name__ == "__main__":
    main()
