"""Phase 4: skewed workload -- block vs cyclic vs dynamic-chunk scheduling."""
import math
import multiprocessing as mp
import time

from harness import (emit_verify_tag, get_p_phys, get_student_seed, md_table, pick,
                     run_benchmark_ret, save_result)

N = pick(12_000, 1_200)
WARM, TIMED = pick((1, 3), (0, 2))        # raise TIMED to 5-7 if you have time
CHUNKS = [1, 4, 16, 64, 256, 1024]


def do_item(i, sin=math.sin, cos=math.cos, sqrt=math.sqrt):
    x = i * 0.001 + 0.5
    for _ in range(1 + (i * i) // 3600):               # K(i) = 1 + floor((i/60)^2)
        x = sqrt(abs(sin(x) * cos(x))) + 0.5
    return x


def worker(kind, t, p, chunk, times, counter):
    t0 = time.perf_counter_ns()
    acc = 0.0
    if kind == "block":
        for i in range(t * N // p, (t + 1) * N // p):
            acc += do_item(i)
    elif kind == "cyclic":
        for i in range(t, N, p):
            acc += do_item(i)
    else:
        while True:
            with counter.get_lock():
                start = counter.value
                counter.value = start + chunk
            if start >= N:
                break
            for i in range(start, min(start + chunk, N)):
                acc += do_item(i)
    times[t] = (time.perf_counter_ns() - t0) / 1e6


def trial(kind, p, chunk):
    times = mp.Array("d", p)
    counter = mp.Value("i", 0)
    t0 = time.perf_counter_ns()
    procs = [mp.Process(target=worker, args=(kind, t, p, chunk, times, counter)) for t in range(p)]
    for pr in procs:
        pr.start()
    for pr in procs:
        pr.join()
    wall = (time.perf_counter_ns() - t0) / 1e6
    return wall, times[:]


def measure(kind, p, chunk=0):
    st, rows = run_benchmark_ret(lambda: trial(kind, p, chunk), WARM, TIMED)
    rows = sorted(rows, key=lambda r: r[0])
    tw = rows[(len(rows) - 1) // 2][1]                 # telemetry from the median run
    lam = max(tw) / (sum(tw) / len(tw))
    return st, lam, tw


def main():
    seed = get_student_seed()
    p = get_p_phys()
    print(f"N={N}, p={p}; K(N-1)/K(0) = {1 + ((N-1)**2)//3600}")
    results = []
    for label, kind, c in [("Strategy 1 (block)", "block", 0), ("Strategy 2 (cyclic)", "cyclic", 0)] + \
                          [(f"Strategy 3 (C={c})", "dynamic", c) for c in CHUNKS]:
        st, lam, tw = measure(kind, p, c)
        results.append((label, c, st, lam, tw))
        print(f"  {label:<22} T_wall={st.median_ms:9.0f} ms  lambda={lam:.3f}")

    dyn = [r for r in results if r[0].startswith("Strategy 3")]
    best = min(dyn, key=lambda r: r[2].median_ms)
    c_star = best[1]
    tbl = md_table(["Strategy", "T_wall median (ms)", "IQR (ms)", "lambda", "min/max worker (ms)"],
                   [[r[0] + (" <- C*" if r[1] == c_star and r[0].startswith("Strategy 3") else ""),
                     f"{r[2].median_ms:.0f}", f"{r[2].iqr_ms:.0f}", f"{r[3]:.3f}",
                     f"{min(r[4]):.0f} / {max(r[4]):.0f}"] for r in results])
    tag = emit_verify_tag("PHASE4", seed, results[0][2].median_ms, best[2].median_ms)
    print("\n" + tbl + "\n" + tag)
    analysis = (
        f"C* = {c_star} (T_wall {best[2].median_ms:.0f} ms, lambda {best[3]:.3f}) versus block "
        f"{results[0][2].median_ms:.0f} ms (lambda {results[0][3]:.2f}) and cyclic "
        f"{results[1][2].median_ms:.0f} ms (lambda {results[1][3]:.2f}).\n\n"
        "**Block static** is worst: work grows quadratically with i, so the last worker's contiguous "
        "range holds most of the work while the others idle at the join barrier (lambda >> 1). "
        "**Cyclic** interleaves cheap and expensive items, so each worker's total is almost equal "
        "(lambda ~ 1) with zero synchronization. **Dynamic, C=1**: best balance (tail skew of one item) "
        "but every item pays a lock acquire/release on a shared counter in its own cache line, i.e. "
        "inter-process lock traffic and coherence ping-pong; cost is visible only when items are cheap "
        "(early indices). **Dynamic, C=1024**: only ~12 chunks exist and chunks are claimed in "
        "increasing index order, so the heaviest chunk is claimed LAST and runs alone at the end - a "
        "large tail imbalance. C* sits between: chunks small enough that the last chunk is short, large "
        "enough that lock overhead is amortized.")
    save_result("task4", dict(verify=tag, md=tbl, analysis=analysis))


if __name__ == "__main__":
    main()
