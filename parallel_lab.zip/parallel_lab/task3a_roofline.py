"""Phase 3A: empirical machine roofline (DRAM bandwidth + Python FMA ceiling)."""
import multiprocessing as mp
import time
from multiprocessing import shared_memory

from harness import (attach_shm, get_p_phys, md_table, pick, run_benchmark_ret, save_result)

SIZE = pick(96_000_000, 4_000_000)                 # 96 MB per buffer
FLOPS_PER_WORKER = pick(80_000_000, 800_000)       # 8.0e7
WARM, TIMED = pick((1, 5), (1, 2))


def bw_worker(name_a, name_b, size, t, p, barrier, times):
    a, b = attach_shm(name_a), attach_shm(name_b)
    mv_a, mv_b = a.buf, b.buf
    start, end = size * t // p, size * (t + 1) // p
    barrier.wait()
    t0 = time.perf_counter_ns()
    mv_a[start:end] = mv_b[start:end]              # native memcpy
    times[t] = (time.perf_counter_ns() - t0) / 1e6
    del mv_a, mv_b
    a.close()
    b.close()


def fma_worker(iters, t, barrier, times):
    a, b = 0.999999, 1e-6
    x0 = x1 = x2 = x3 = x4 = x5 = x6 = x7 = 1.0
    x8 = x9 = x10 = x11 = x12 = x13 = x14 = x15 = 1.0
    barrier.wait()
    t0 = time.perf_counter_ns()
    for _ in range(iters):
        x0 = x0 * a + b
        x1 = x1 * a + b
        x2 = x2 * a + b
        x3 = x3 * a + b
        x4 = x4 * a + b
        x5 = x5 * a + b
        x6 = x6 * a + b
        x7 = x7 * a + b
        x8 = x8 * a + b
        x9 = x9 * a + b
        x10 = x10 * a + b
        x11 = x11 * a + b
        x12 = x12 * a + b
        x13 = x13 * a + b
        x14 = x14 * a + b
        x15 = x15 * a + b
    times[t] = (time.perf_counter_ns() - t0) / 1e6
    return x0 + x15


def run_parallel(p, target, make_args):
    barrier = mp.Barrier(p)
    times = mp.Array("d", p)
    procs = [mp.Process(target=target, args=make_args(t, barrier, times)) for t in range(p)]
    for pr in procs:
        pr.start()
    for pr in procs:
        pr.join()
    return max(times[:]), None                     # slowest worker defines the trial


def main():
    p = get_p_phys()
    A = shared_memory.SharedMemory(create=True, size=SIZE)
    B = shared_memory.SharedMemory(create=True, size=SIZE)
    try:
        B.buf[:] = b"\x01" * SIZE                  # touch pages so DRAM is resident
        A.buf[:] = b"\x00" * SIZE
        st_bw, _ = run_benchmark_ret(
            lambda: run_parallel(p, bw_worker,
                                 lambda t, bar, tm: (A.name, B.name, SIZE, t, p, bar, tm)),
            WARM, TIMED)
    finally:
        A.close(); B.close(); A.unlink(); B.unlink()
    bw = 2 * SIZE / (st_bw.median_ms / 1e3 * 1e9)  # GB/s (1 read + 1 write per byte)

    iters = FLOPS_PER_WORKER // 32                 # 16 statements x 2 FLOP (mul+add) per iteration
    st_fp, _ = run_benchmark_ret(
        lambda: run_parallel(p, fma_worker, lambda t, bar, tm: (iters, t, bar, tm)), WARM, TIMED)
    gflops = p * FLOPS_PER_WORKER / (st_fp.median_ms / 1e3 * 1e9)
    ridge = gflops / bw

    tbl = md_table(["Quantity", "Value"], [
        ["Workers (P_phys)", p],
        ["DRAM copy median time (ms)", f"{st_bw.median_ms:.2f}"],
        ["BW_sustained (GB/s)", f"{bw:.3f}"],
        ["FMA median time (ms)", f"{st_fp.median_ms:.1f}"],
        ["P_sustained (GFLOP/s)", f"{gflops:.4f}"],
        ["Ridge point I* (FLOP/Byte)", f"{ridge:.5f}"]])
    print(tbl)
    analysis = (f"BW_sustained = 2 x {SIZE/1e6:.0f}e6 B / T_median = {bw:.2f} GB/s; "
                f"P_sustained = {gflops:.4f} GFLOP/s (counting mul+add as 2 FLOP; the loop does "
                f"{iters:,} iterations x 16 statements per worker); ridge I* = {ridge:.5f} FLOP/B. "
                f"Because the compute ceiling is set by CPython bytecode dispatch rather than SIMD "
                f"FMA units, I* is tiny: almost any kernel in this lab is on the compute-bound side "
                f"of this *Python* roofline, even though it would be memory-bound for native code.")
    save_result("task3a", dict(bw_gbs=bw, p_gflops=gflops, ridge=ridge, p_phys=p,
                               md=tbl, analysis=analysis))


if __name__ == "__main__":
    main()
