"""Run every phase in order, then build the report.  Usage: python run_all.py"""
import subprocess
import sys

STEPS = ["task0_cal.py", "task1_falsesharing.py", "task2_scaling.py",
         "task3a_roofline.py", "task3b_gemm.py", "task4_scheduling.py", "make_report.py"]

if __name__ == "__main__":
    for s in STEPS:
        print(f"\n===== {s} =====", flush=True)
        if subprocess.call([sys.executable, s]) != 0:
            sys.exit(f"{s} failed")
