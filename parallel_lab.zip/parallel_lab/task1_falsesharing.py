"""Phase 1: false sharing stride sweep + Karp-Flatt diagnostic series."""
import ctypes
import multiprocessing as mp
from multiprocessing import shared_memory

from harness import (emit_verify_tag, get_p_log, get_p_phys, get_student_seed, md_table, p_sweep, pick,
                     run_benchmark, save_result)

M_TOTAL = pick(24_000_000, 480_000)          # M = 2.4e7 total RMW steps
WARM, TIMED = pick((2, 7), (1, 2))           # spec: warmup_runs=2, timed_runs=7
STRIDES = [1, 2, 4, 8, 16, 32]


def fs_worker(shm_name: str, slot_idx: int, iters: int) -> None:
    shm = shared_memory.SharedMemory(name=shm_name)
    arr = (ctypes.c_uint64 * (shm.size // 8)).from_buffer(shm.buf)
    acc = arr[slot_idx]
    mask = 0xFFFFFFFFFFFFFFFF
    mult = 6364136223846793005
    for i in range(iters):
        acc = (acc * mult + (i | 1)) & mask
        arr[slot_idx] = acc            # store to a (possibly shared) cache line
    del arr                            # release buffer export before close
    shm.close()


def bench(p: int, stride: int):
    size = max(4096, (p * stride + 1) * 8)      # 4096 B unless p*stride needs more
    shm = shared_memory.SharedMemory(create=True, size=size)
    iters = M_TOTAL // p

    def trial():
        procs = [mp.Process(target=fs_worker, args=(shm.name, t * stride, iters))
                 for t in range(p)]
        for pr in procs:
            pr.start()
        for pr in procs:
            pr.join()
    try:
        return run_benchmark(trial, WARM, TIMED)
    finally:
        shm.close()
        shm.unlink()


def karp_flatt(S, p):
    return (1 / S - 1 / p) / (1 - 1 / p)


def main():
    seed = get_student_seed()
    p_phys, p_log = get_p_phys(), get_p_log()
    print(f"P_phys={p_phys}  P_log={p_log}  M={M_TOTAL:,}")

    # ---- Table 1A: stride sweep at p = P_phys
    st = {}
    for s in STRIDES:
        st[s] = bench(p_phys, s)
        print(f"  stride={s:>2} ({s*8:>3} B): median {st[s].median_ms:9.1f} ms")
    rows, ratios = [], {}
    for i, s in enumerate(STRIDES):
        b = st[s]
        if i:
            ratios[s] = st[STRIDES[i - 1]].median_ms / b.median_ms
        rows.append([s, s * 8, f"{b.median_ms:.1f}", f"{b.iqr_ms:.1f}",
                     f"{M_TOTAL / (b.median_ms * 1e3):.2f}"])
    t1a = md_table(["Stride (words)", "Byte offset", "Median (ms)", "IQR (ms)", "Mops/s"], rows)
    best_s = max(ratios, key=ratios.get)
    drop_msg = (f"Largest drop in execution time occurs at stride={best_s} ({best_s*8} B): "
                f"{ratios[best_s]:.2f}x faster than stride={STRIDES[STRIDES.index(best_s)-1]}.")
    precipitous = ratios[best_s] >= 1.15

    # ---- Table 1B: scaling sweep at stride 1 and 16
    ps = p_sweep(p_phys, p_log)
    series = {}
    for stride in (1, 16):
        T = {p: bench(p, stride).median_ms for p in ps}
        series[stride] = T
        print(f"  stride={stride}: " + ", ".join(f"p={p}:{T[p]:.0f}ms" for p in ps))
    rows1b, e_at = [], {1: {}, 16: {}}
    for stride in (1, 16):
        T = series[stride]
        for p in ps:
            S = T[1] / T[p]
            E = S / p
            e = karp_flatt(S, p) if p >= 2 else None
            e_at[stride][p] = e
            rows1b.append([stride, p, f"{T[p]:.1f}", f"{S:.3f}", f"{E:.3f}",
                           "-" if e is None else f"{e:.4f}"])
    t1b = md_table(["Stride", "p", "T_p (ms)", "S_p", "E_p", "e(p)"], rows1b)

    m1, m16 = st[1].median_ms, st[16].median_ms
    tag = emit_verify_tag("PHASE1", seed, m1, m16)
    print("\n" + t1a + "\n" + drop_msg + "\n\n" + t1b + "\n" + tag)

    e1 = e_at[1].get(p_phys) or e_at[1].get(max(e_at[1]))
    e16 = e_at[16].get(p_phys) or e_at[16].get(max(e_at[16]))
    if e1 and e16 and e1 > 1.5 * e16 and m1 > 1.15 * m16:
        verdict = (f"The data confirm false sharing: at p={p_phys}, e(p) is {e1:.3f} for stride=1 "
                   f"versus {e16:.3f} for stride=16, and median time falls from {m1:.0f} ms to "
                   f"{m16:.0f} ms.")
    else:
        verdict = (f"False sharing is muted on this machine/interpreter: at p={p_phys}, e(p) is "
                   f"{e1} (stride=1) vs {e16} (stride=16) and time is {m1:.0f} vs {m16:.0f} ms. "
                   f"CPython spends ~100+ ns of interpreter work per iteration, which hides much of "
                   f"the coherence cost; report this honestly.")
    analysis = (
        verdict + "\n\n"
        "**Mechanism.** With stride=1 the p slots are 8 bytes apart, so up to 8 (64 B line) or 16 "
        "(128 B line) workers' slots share ONE cache line. Every store needs the line in Modified "
        "state, forcing a MESI/MOESI invalidation of the copy in every other core's L1; the line "
        "ping-pongs between cores and stores serialize. No code is serial, yet the hardware makes "
        "the stores behave as if it were, which Amdahl/Karp-Flatt reads as a growing serial fraction: "
        "e(p) rises with p. With stride=16 (128 B) each slot sits on its own line, there is no "
        "invalidation traffic, and e(p) stays near its small floor (process spawn/join overhead).\n\n"
        f"**Cache line width.** {drop_msg} "
        + ("A drop at 64 B => 64-byte line (x86-64); at 128 B => 128-byte line (Apple M-series)."
           if precipitous else "No sharp step was found, so the line width cannot be read from timing alone; "
           "use the OS-reported value."))
    save_result("task1", dict(verify=tag, md=t1a + "\n\n" + drop_msg + "\n\n" + t1b,
                              analysis=analysis))


if __name__ == "__main__":
    main()
