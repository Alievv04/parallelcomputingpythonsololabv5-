"""Phase 2: strong (Amdahl) vs weak (Gustafson) scaling, p = 1..P_log."""
import math
import multiprocessing as mp
import time

from harness import (emit_verify_tag, get_p_log, get_p_phys, get_student_seed, md_table, pick,
                     run_benchmark_ret, save_result, summarize)

N_STRONG = pick(1_600_000, 16_000)
N0 = pick(250_000, 2_500)
WARM, TIMED = pick((1, 5), (1, 2))
STAGE_B_ITERS = 35


def stage_a(n_a: int) -> float:
    """Serial: 12 transcendental ops (6 x sin + 6 x sqrt) per element."""
    acc = 0.0
    sin, sqrt = math.sin, math.sqrt
    for i in range(n_a):
        x = (i + 1) * 1e-3
        for _ in range(6):
            x = sqrt(sin(x) + 1.5)
        acc += x
    return acc


def kernel(bounds):
    """Parallel: 35 multiply-add + trig iterations per element, no shared writes."""
    start, end = bounds
    sin, cos = math.sin, math.cos
    acc = 0.0
    for i in range(start, end):
        x = i * 1e-6
        for _ in range(STAGE_B_ITERS):
            x = x * 0.999999 + 0.5
            x = 0.5 * sin(x) + 0.5 * cos(x) + 1e-3
        acc += x
    return acc


def trial(pool, p, N):
    bounds = [(N * t // p, N * (t + 1) // p) for t in range(p)]
    t0 = time.perf_counter_ns()
    stage_a(int(0.05 * N))
    t1 = time.perf_counter_ns()
    pool.map(kernel, bounds, chunksize=1)
    t2 = time.perf_counter_ns()
    return (t2 - t0) / 1e6, (t1 - t0) / 1e6


def main():
    seed = get_student_seed()
    p_phys, p_log = get_p_phys(), get_p_log()
    ps = list(range(1, p_log + 1))
    strong, weak = {}, {}
    for p in ps:
        with mp.Pool(processes=p) as pool:           # created OUTSIDE the timed region
            for store, N in ((strong, N_STRONG), (weak, p * N0)):
                st, rows = run_benchmark_ret(lambda: trial(pool, p, N), WARM, TIMED)
                a_med = summarize([r[1] for r in rows]).median_ms
                store[p] = (st.median_ms, a_med)
        print(f"  p={p:>2}: strong {strong[p][0]:9.1f} ms | weak {weak[p][0]:9.1f} ms")

    T1 = strong[1][0]
    s = strong[1][1] / T1
    s_inf = 1 / s
    amdahl_log = 1 / (s + (1 - s) / p_log)
    rows2a, S = [], {}
    for p in ps:
        S[p] = T1 / strong[p][0]
        rows2a.append([p, f"{strong[p][0]:.1f}", f"{S[p]:.3f}", f"{S[p]/p:.3f}",
                       "-" if p == 1 else f"{S[p]-S[p-1]:+.3f}"])
    t2a = md_table(["p", "T_strong (ms)", "S_p", "E_p", "Marginal dS"], rows2a)

    W1 = weak[1][0]
    rows2b, G = [], {}
    for p in ps:
        alpha = weak[p][1] / weak[p][0]
        G[p] = p - alpha * (p - 1)
        rows2b.append([p, f"{weak[p][0]:.1f}", f"{W1/weak[p][0]:.3f}", f"{alpha:.4f}", f"{G[p]:.3f}"])
    t2b = md_table(["p", "T_weak (ms)", "E_weak", "alpha", "S_Gustafson"], rows2b)

    boundary = ""
    if p_phys < p_log:
        mb = S[p_phys] - S[p_phys - 1] if p_phys > 1 else S[1]
        ma = S[p_phys + 1] - S[p_phys]
        drop = f"{(mb - ma) / mb * 100:.1f}% drop" if mb > 0 else "n/a (non-positive baseline marginal speedup)"
        boundary = (f"Crossing p={p_phys}->{p_phys+1}: marginal speedup per added worker goes from "
                    f"{mb:.3f} to {ma:.3f}: **{drop}**. Beyond the physical cores, extra "
                    f"workers are SMT/E-core siblings that share execution ports and L1/L2.")
    else:
        boundary = ("P_phys == P_log (no SMT detected / P_PHYS override): no physical->logical "
                    "boundary to analyse; discuss any hybrid P/E-core knee visible in Marginal dS.")

    tag = emit_verify_tag("PHASE2", seed, S[p_log], G[p_log])
    txt = (f"Serial fraction s = T_StageA(1)/T_strong(1) = {s:.5f}; Amdahl S_inf = 1/s = {s_inf:.1f}; "
           f"theoretical S(P_log={p_log}) = {amdahl_log:.3f}; observed S(P_log) = {S[p_log]:.3f} "
           f"({S[p_log]/amdahl_log*100:.1f}% of theory).\n\n{boundary}")
    print("\n" + t2a + "\n\n" + t2b + "\n\n" + txt + "\n" + tag)
    analysis = (txt + "\n\nObserved speedup falls below Amdahl's bound because of (i) SMT siblings that do not "
                "add full cores, (ii) pool IPC/pickling and process-start costs, (iii) turbo/thermal "
                "frequency drop under load, and (iv) background load. In weak scaling the serial Stage A "
                "grows with N(p) (it is 5% of N), so alpha is not constant and Gustafson speedup "
                "sits below the ideal p.")
    save_result("task2", dict(verify=tag, analysis=analysis,
                              md=t2a + "\n\n" + t2b))


if __name__ == "__main__":
    main()
